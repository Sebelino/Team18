'''
External libraries
==================

Kivy come with other python/c libraries :

* ddslib
* oscAPI (modified / optimized)
* mtdev

.. warning::

    Even if Kivy come with theses external libraries, we don't give any support,
    and we might change in the future. Don't rely on theses in your code.

'''
