'''
Network support
===============

Kivy start to have some support for network request.
Right now, check :class:`kivy.network.urlrequest.UrlRequest` !
'''
