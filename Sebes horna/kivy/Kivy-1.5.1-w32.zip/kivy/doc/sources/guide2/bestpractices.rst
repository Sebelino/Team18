.. _bestpractices:

Best Practices
==============

Designing your Application code
-------------------------------

Handle Window resizing
----------------------

Managing resources
------------------

Platform consideration
----------------------

