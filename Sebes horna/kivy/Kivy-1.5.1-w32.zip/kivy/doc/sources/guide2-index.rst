Programming Guide 2
===================

.. warning::

    We are currently refactoring the whole Programming Guide. This is a work in
    progress, and might change at any times.

.. toctree::
    :maxdepth: 2

    guide2/basic
    guide2/events
    guide2/widgets
    guide2/graphics
    guide2/lang
    guide2/bestpractices
    guide2/advancedgraphics
    guide2/packaging
